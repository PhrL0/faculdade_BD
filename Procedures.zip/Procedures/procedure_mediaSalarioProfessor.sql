CREATE DEFINER=`root`@`localhost` PROCEDURE `media_salario_prof`()
BEGIN
	SELECT AVG(salario) AS media_salarial FROM colaboradores WHERE cargo='Professor';
END