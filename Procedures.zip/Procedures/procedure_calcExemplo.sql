CREATE DEFINER=`root`@`localhost` PROCEDURE `calc_exemplo`()
BEGIN
	select(1 + 5)/ 2 as Resultado;
END