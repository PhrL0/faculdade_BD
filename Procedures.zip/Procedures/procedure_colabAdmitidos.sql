CREATE DEFINER=`root`@`localhost` PROCEDURE `colabAdmitidos`()
BEGIN
	SELECT nome,cargo,data_admissao,departamento FROM colaboradores
    WHERE data_admissao > '20160101';
END