CREATE DEFINER=`root`@`localhost` PROCEDURE `lista_professor`()
BEGIN
	SELECT nome,pais,estado,cidade,rua,numero,cep,telefone_celular,cargo,departamento,salario,nacionalidade
    FROM colaboradores WHERE cargo='Professor';
END