CREATE DEFINER=`root`@`localhost` PROCEDURE `salariosMax`()
BEGIN
	SELECT nome,cargo,departamento,salario FROM colaboradores
    WHERE salario > 2200;
END