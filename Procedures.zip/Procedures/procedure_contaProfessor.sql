CREATE DEFINER=`root`@`localhost` PROCEDURE `conta_professor`()
BEGIN
	DECLARE contagem INT;
    SELECT COUNT(*) INTO contagem FROM colaboradores WHERE cargo='Professor';
    IF contagem > 0 THEN
		SELECT contagem;
	ELSE 
		SELECT'Nenhum funcionário com cargo Professor';
	END IF;
END