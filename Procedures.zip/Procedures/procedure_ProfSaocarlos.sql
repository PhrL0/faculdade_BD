CREATE DEFINER=`root`@`localhost` PROCEDURE `profSaocarlos`()
BEGIN
	SELECT nome,telefone_celular,cidade,rua,cep,numero,cargo FROM colaboradores 
    WHERE cargo='Professor' AND cidade='São Carlos';
END