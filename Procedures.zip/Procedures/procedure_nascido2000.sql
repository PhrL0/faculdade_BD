CREATE DEFINER=`root`@`localhost` PROCEDURE `nascidos2000`()
BEGIN
	DECLARE aux VARCHAR(20) DEFAULT '20001230';
    IF aux < '20010101' THEN
		SELECT nome,data_nascimento,cargo,departamento FROM colaboradores;
	ELSE
		SELECT 'Nenhum funcionario encontrado';
	END IF;
END