import mysql.connector

conexao = mysql.connector.connect(
    host = 'localhost',
    user = 'root',
    password = 'aluno',
    database = 'clientes',
)

cursor = conexao.cursor()

#CRUD 

#INSERT

a = input("Digite seu nome:")
b = input("Digite sua idade:")
#comando = f'INSERT INTO cliente(nome,idade,profissao,data_admissao) VALUES ("Paulo",33,"Professor", "20020812")'
comando = f'INSERT INTO cliente(nome,idade) VALUES (%s,%s)'
valores = (a,b)
cursor.execute(comando,valores)
conexao.commit()#Edita Banco de dados

#READ
comando = f'SELECT * FROM cliente'
cursor.execute(comando)
resultado = cursor.fetchall()#Ler banco de dados
print(resultado)

cursor.close()
conexao.close()


