import streamlit as st

st.set_page_config(
    page_title="Bem-vindo",
    page_icon=":Home:"
)

st.sidebar.success("Página Principal")

st.write("## Bem-vindo ao sistema de cadastro!")

